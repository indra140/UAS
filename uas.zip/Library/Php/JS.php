<!-- JQuery 3 -->
<script type="text/javascript" src="../Library/Js/JQuery-Min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script type="text/javascript"  src="../Library/Js/Bootstrap-Min.js"></script>
<!-- ICheck JS -->
<script type="text/javascript"  src="../Library/Js/JQuery-Select-Full-Min.js"></script>
<!-- Fast Click -->
<script type="text/javascript"  src="../Library/Js/JQuery-Fast-Click.js"></script>
<!-- AdminLTE App -->
<script type="text/javascript"  src="../Library/Js/AdminLTE.Min.js"></script>
<!-- Spark Line -->
<script type="text/javascript"  src="../Library/Js/JQuery-Spark-Line-Min.js"></script>
<!-- JVector Map  -->
<script type="text/javascript"  src="../Library/Js/JQuery-JVector-Map-1.2.2-Min.js"></script>
<script type="text/javascript"  src="../Library/Js/JQuery-JVector-Map-World-Mill.js"></script>
<!-- JQuery Data Tables  -->
<script type="text/javascript"  src="../Library/Js/JQuery-Data-Tables-Min.js"></script>
<script type="text/javascript"  src="../Library/Js/JQuery-Data-Tables-Bootstrap-Min.js"></script>
<!-- Slim Scroll -->
<script type="text/javascript"  src="../Library/Js/JQuery-Slim-Scroll-Min.js"></script>
<!-- Chart JS -->
<script type="text/javascript"  src="../Library/Js/JQuery-Chart.js"></script>
<script type="text/javascript"  src="../Library/Js/JQuery-Input-Mask.js"></script>
<script type="text/javascript"  src="../Library/Js/JQuery-Input-Mask-Extensions.js"></script>
<!-- ICheck JS -->
<script type="text/javascript"  src="../Library/Js/JQuery-ICheck-Min.js"></script>
<!-- JQuery  Mockjax >
<script type="text/javascript"  src="Library/Js/JQuery-Mockjax.js"></script -->
<!-- JQuery  Validate >
<script type="text/javascript"  src="Library/Js/JQuery-Validate-Min.js"></script -->
<!-- AdminLTE Dashboard Demo (This Is Only For Demo Purposes) -->
<script type="text/javascript"  src="../Library/Js/JQuery-Dashboard.js"></script>
<!-- AdminLTE For Demo Purposes -->
<script type="text/javascript"  src="../Library/Js/JQuery-Demo.js"></script>
<!-- AdminLTE For Demo Purposes -->
<script type="text/javascript"  src="../Library/Js/JQuery-Tools.js"></script>